## Direitos Autorais

Este projeto é protegido por direitos autorais. Não é permitido o uso, distribuição ou modificação do código sem a permissão expressa do autor, salvo as condições previstas na [licença do projeto](/license).