Oque e o Chat? E um sistema de faq profissonal usando auto responde.

Linguagens? html uns 67% Css uns 16,5% Python uns 16,5%

# 98% Uso de chatgpt.